### The SpatBox now provide geospatial analysis algorithm APIS

from . import GD, GWR
