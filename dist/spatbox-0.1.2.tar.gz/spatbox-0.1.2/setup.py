import setuptools

setuptools.setup(
    name="spatbox",
    version="0.1.2",
    long_description="A Python Library For GeoSpatial Data Proressing",
    author="SpatLyu",
    author_email="3180929657@qq.com",
    packages=['spatbox'],
)
