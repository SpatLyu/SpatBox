__version__ = "0.1.2",
__author__ = "SpatLyu"


import spatbox.datasets 
import spatbox.vector
import spatbox.raster 



