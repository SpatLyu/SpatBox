### The SpatBox provide downscale model to achive gridding of geospatial data

import spatbox.model.gwann
import spatbox.model.srgcnn
