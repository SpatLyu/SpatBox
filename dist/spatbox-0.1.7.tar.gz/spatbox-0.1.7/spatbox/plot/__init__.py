### plot_geospatial_data

import spatbox.plot.colormaps