### This module provide tools to process the raster data

import spatbox.raster.mask, spatbox.raster.reproject, spatbox.raster.resample
import spatbox.raster.convert