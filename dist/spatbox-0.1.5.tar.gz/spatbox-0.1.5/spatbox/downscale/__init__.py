### The SpatBox provide downscale model to achive gridding of geospatial data

import numpy as np 
import spatbox.downscale.gwann
import spatbox.downscale.srgcnn
