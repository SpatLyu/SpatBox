__version__ = "0.1.5",
__author__ = "SpatLyu"

import spatbox as stx
import spatbox.datasets 
import spatbox.vector
import spatbox.raster 



